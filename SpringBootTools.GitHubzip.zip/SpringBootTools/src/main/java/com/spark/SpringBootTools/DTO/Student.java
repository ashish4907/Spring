package com.spark.SpringBootTools.DTO;
import org.springframework.context.annotation.Scope;

import org.springframework.stereotype.Component;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Component
@Entity
@Table(name = "STUDENT_DETAIL")
@Scope("prototype")
public class Student {
    @Id
    @Column(name = "STUDENT_ID")
    private  Integer studentId;

    @Column(name = "STUDENT_NAME")
    private String studentName;

    public int getStudentId() {
        return studentId;
    }
    public void setStudentId(int studentId) {
        this.studentId = studentId;
    }
    public String getStudentName() {
        return studentName;
    }
    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }
}
