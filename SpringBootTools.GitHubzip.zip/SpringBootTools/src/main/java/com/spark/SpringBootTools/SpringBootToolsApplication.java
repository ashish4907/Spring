package com.spark.SpringBootTools;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;

@SpringBootApplication
//@EnableAutoConfiguration(exclude = DataSourceAutoConfiguration.class)
public class SpringBootToolsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootToolsApplication.class, args);
		System.out.println("Hello");
	}

}
