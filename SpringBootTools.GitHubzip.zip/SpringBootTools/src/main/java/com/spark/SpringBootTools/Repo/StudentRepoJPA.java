package com.spark.SpringBootTools.Repo;

import com.spark.SpringBootTools.DTO.Student;
import com.spark.SpringBootTools.DTO.StudentForm;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepoJPA extends JpaRepository <StudentForm, Integer>{
    Optional<StudentForm> findById(Integer integer);
    StudentForm findBystudentId(Integer id);


}
