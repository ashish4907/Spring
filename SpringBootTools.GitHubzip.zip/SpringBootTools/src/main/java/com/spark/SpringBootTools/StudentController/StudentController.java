package com.spark.SpringBootTools.StudentController;

import com.spark.SpringBootTools.DTO.Student;
import com.spark.SpringBootTools.DTO.StudentForm;
import com.spark.SpringBootTools.DTO.StudentResponse;
import com.spark.SpringBootTools.Repo.StudentRepoCrud;
import com.spark.SpringBootTools.Repo.StudentRepoJPA;
import com.spark.SpringBootTools.ServiceImpl.StudentServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;


@RestController
public class StudentController {

    @Autowired
    private StudentServiceImpl studentServiceImpl;


    @GetMapping("/fetch")
    public StudentResponse fetchStudentDetails() {
        return studentServiceImpl.fetchStudentDetails();
    }

@PostMapping("/add")
    public StudentResponse add(@RequestBody StudentForm studentForm) {
        return studentServiceImpl.add(studentForm);
    }

    @PostMapping("/update")
    public StudentResponse update(@RequestBody StudentForm studentForm){
        return studentServiceImpl.update(studentForm);
    }

    @DeleteMapping("/delete")
    public StudentResponse delete(@RequestParam Integer id){

        return studentServiceImpl.delete(id);
    }


     /*@Autowired
    private StudentServiceImpl studentServiceimpl;*/
  /*  @Autowired
    private StudentRepoCrud studentRepoCrud;*/

   /* @GetMapping("/fetchAllCrud")
    public Iterable<Student> fetchDetailsCrud() {
        return (studentRepoCrud.findAll());
    }

    @GetMapping("/fetchAllJPA")
    public List<Student> fetchDetailsJPA() {
       return studentRepoJPA.findAll();
    }

    @GetMapping("/fetchByIdJPA")
    public Optional<Student> fetchById() {
       return studentRepoJPA.findById(2);
    }

    @GetMapping("/fetchByNameJPA")
    public List<Student> fetchByName() {
        return studentRepoJPA.findBystudentName("A");
    }*/



/*    @GetMapping("/getAllCrud")
    public List<Student> getAll() {
        return studentRepoCrud.getAll();
    }*/


}
