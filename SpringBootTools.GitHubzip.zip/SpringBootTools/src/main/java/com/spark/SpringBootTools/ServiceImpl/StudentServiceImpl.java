package com.spark.SpringBootTools.ServiceImpl;

import com.spark.SpringBootTools.DTO.StudentForm;
import com.spark.SpringBootTools.DTO.StudentResponse;
import com.spark.SpringBootTools.Repo.StudentRepoJPA;
import com.spark.SpringBootTools.Service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;
import java.util.Optional;

@Service
public class StudentServiceImpl implements StudentService {

    @Autowired
    private StudentRepoJPA studentRepoJPA;
    @Autowired
    private StudentResponse studentResponse;


    @Override
    public StudentResponse fetchStudentDetails() {
        List<StudentForm> all = studentRepoJPA.findAll();
        if (all != null) {
            studentResponse.setStatusCode(HttpStatus.OK.value() + "");
            studentResponse.setStatusMessage("Success");
            studentResponse.setList(studentRepoJPA.findAll());
            return studentResponse;

        }

        studentResponse.setStatusCode(HttpStatus.BAD_REQUEST.value() + "");
        studentResponse.setStatusMessage("Fail");
        studentResponse.setList(studentRepoJPA.findAll());
        return studentResponse;
    }

    @Override

    public StudentResponse add(@RequestBody StudentForm studentForm) {
        if (studentForm != null && studentForm.getStudentName() != null && !studentForm.getStudentName().isEmpty()) {
            StudentForm save = studentRepoJPA.save(studentForm);
            if (save != null) {
                studentResponse.setStatusCode(HttpStatus.OK.value() + "");
                studentResponse.setStatusMessage("Success");
                studentResponse.setList(studentRepoJPA.findAll());
                return studentResponse;
            }
        }
        studentResponse.setStatusCode(HttpStatus.BAD_REQUEST.value() + "");
        studentResponse.setStatusMessage("Fail");
        studentResponse.setList(studentRepoJPA.findAll());
        return studentResponse;

    }

    @Override
    public StudentResponse delete(Integer id) {
        if (studentRepoJPA.existsById(id)) {
            studentRepoJPA.deleteById(id);

            studentResponse.setStatusCode(HttpStatus.OK.value() + "");
            studentResponse.setStatusMessage("Success");
            studentResponse.setList(studentRepoJPA.findAll());
            return studentResponse;
        }
        studentResponse.setStatusCode(HttpStatus.BAD_REQUEST.value() + "");
        studentResponse.setStatusMessage("Fail");
        studentResponse.setList(studentRepoJPA.findAll());
        return studentResponse;

    }


    @Override
    public StudentResponse update(@RequestBody StudentForm studentForm) {
        if (studentForm != null && studentForm.getStudentName() != null && !studentForm.getStudentName().isEmpty() && !studentForm.getEducation().isEmpty() && studentForm.getEducation() != null) {
            if (studentRepoJPA.existsById(studentForm.getStudentId())) {

                StudentForm updateStudent = studentRepoJPA.findBystudentId(studentForm.getStudentId());

                updateStudent.setStudentName(studentForm.getStudentName());
                updateStudent.setPhoneNumber(studentForm.getPhoneNumber());
                updateStudent.setEmail(studentForm.getEmail());
                updateStudent.setEducation(studentForm.getEducation());
                updateStudent.setAddress(studentForm.getAddress());
                updateStudent.setGender(studentForm.getGender());

                studentRepoJPA.save(updateStudent);
                studentResponse.setStatusCode(HttpStatus.OK.value() + "");
                studentResponse.setStatusMessage("Success");
                studentResponse.setList(studentRepoJPA.findAll());
                return studentResponse;

            }
        }
        studentResponse.setStatusCode(HttpStatus.BAD_REQUEST.value() + "");
        studentResponse.setStatusMessage("Fail");
        studentResponse.setList(studentRepoJPA.findAll());
        return studentResponse;
    }



















 /*   @Autowired
private Student student;*/

    /*@Autowired
    Student student1;

    @Autowired
    Student student2;

    @Autowired
    Student student3;
    @Autowired
    Student student4;

    @Override
    public List<Student> fetchStudentDetails() {
        return this.setStudentDetails();
    }
    private List<Student> setStudentDetails() {

        ArrayList<Student> list = new ArrayList<>();

        student1.setStudentId(101);
        student1.setStudentName("Nidhi");

        student2.setStudentId(102);
        student2.setStudentName("Megha");

        student3.setStudentId(103);
        student3.setStudentName("Shreya");

        student4.setStudentId(104);
        student4.setStudentName("Shivani");

        return Arrays.asList(student1,student2,student3,student4);
    }*/
}
