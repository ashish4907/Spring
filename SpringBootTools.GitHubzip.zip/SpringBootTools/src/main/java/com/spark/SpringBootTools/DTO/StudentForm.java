package com.spark.SpringBootTools.DTO;


import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

import javax.persistence.*;

@Component
@Entity
@Table(name = "STUDENT_DETAILS")
@Scope("prototype")
public class StudentForm {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "STUDENT_ID")
    private  Integer studentId;
    @Column(name = "STUDENT_NAME")
    private String studentName;
    @Column(name = "PHONE_NUMBER")
    private Long phoneNumber;
    @Column(name = "STUDENT_EMAIL")
    private String Email;
    @Column(name = "STUDENT_EDUCATION")
    private String Education;
    @Column(name = "STUDENT_ADDRESS")
    private String Address;
    @Column(name = "STUDENT_GENDER")
    private String Gender;

    public Integer getStudentId() {
        return studentId;
    }

    public void setStudentId(Integer studentId) {
        this.studentId = studentId;
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        this.studentName = studentName;
    }

    public Long getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(Long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getEducation() {
        return Education;
    }

    public void setEducation(String education) {
        Education = education;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String gender) {
        Gender = gender;
    }
}
