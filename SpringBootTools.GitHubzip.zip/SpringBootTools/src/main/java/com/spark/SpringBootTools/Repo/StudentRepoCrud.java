package com.spark.SpringBootTools.Repo;

import com.spark.SpringBootTools.DTO.Student;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepoCrud extends CrudRepository<Student, Integer> {

       /* @Override
        Optional<Student> findById(Integer integer);

        List<Student> findBystudentName(String name);


        @Query("from Student")
        public List<Student> getAll();*/
}
