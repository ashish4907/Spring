package com.spark.SpringBootTools.DTO;

import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class StudentResponse {
    private String statusCode;
    private String statusMessage;

    private List<StudentForm> list;

    public List<StudentForm> getList() {
        return list;
    }

    public void setList(List<StudentForm> list) {
        this.list = list;
    }

    public String getStatusCode() {
        return statusCode;
    }

    public void setStatusCode(String statusCode) {
        this.statusCode = statusCode;
    }

    public String getStatusMessage() {
        return statusMessage;
    }

    public void setStatusMessage(String statusMessage) {
        this.statusMessage = statusMessage;
    }
}
