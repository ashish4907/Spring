package com.spark.SpringBootTools.Service;

import com.spark.SpringBootTools.DTO.StudentForm;
import com.spark.SpringBootTools.DTO.StudentResponse;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

public interface StudentService {
    public StudentResponse fetchStudentDetails();

   public StudentResponse add(@RequestBody StudentForm studentForm);


    public StudentResponse delete(Integer id);

    StudentResponse update(@RequestBody StudentForm studentForm);
}
