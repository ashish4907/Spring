package com.spark.SpringBootTools;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootToolsApplicationTests {

	@Test
	void contextLoads() {
	}

}
