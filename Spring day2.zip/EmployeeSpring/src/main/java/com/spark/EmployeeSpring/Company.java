package com.spark.EmployeeSpring;

import java.util.List;

public class Company {
	private String companyName;

	private List<Employee> emp;

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public List<Employee> getEmp() {
		return emp;
	}

	public void setEmp(List<Employee> emp) {
		this.emp = emp;
	}

	@Override
	public String toString() {
		return "Company [companyName=" + companyName + ", emp=" + emp + "]";
	}

	public void employeeDetails() {
		emp.stream().forEach(e -> System.out.println(e.getEmployeeId() + " " + e.getEmployeeName()));
	}

}
