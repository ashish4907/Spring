package com.spark.LifeCycle;

public class LifeCycleBean {
	public void display() {
		System.out.println("I am in LifeCycleTest Object");
	}

	public void init() {
		System.out.println("Initialization begins...");
	}

	public void destroy() {
		System.out.println("All beans are destroyed...");
	}

}
