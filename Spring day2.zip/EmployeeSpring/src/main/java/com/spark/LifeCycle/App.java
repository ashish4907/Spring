package com.spark.LifeCycle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
public static void main(String[] args) {
	AbstractApplicationContext context = new ClassPathXmlApplicationContext("lifecyclespring.xml");
	LifeCycleBean bean =(LifeCycleBean)  context.getBean("lifecycleBean");
//	System.out.println(bean);
	bean.display();
	
	
	System.out.println(bean.getClass().getSimpleName());
	
//	context.close();
	context.registerShutdownHook();
}
}
