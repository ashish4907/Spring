package com.spark.StudentCollectionSpring;

import java.util.List;
import java.util.Map;
import java.util.Set;

public class Student {
private String name;
private List<Long> phoneNo;
private Set<String> address;
private Map<Integer,String> course;
public String getName() {
	return name;
}
public void setName(String name) {
	this.name = name;
}
public List<Long> getPhoneNo() {
	return phoneNo;
}
public void setPhoneNo(List<Long> phoneNo) {
	this.phoneNo = phoneNo;
}
public Set<String> getAddress() {
	return address;
}
public void setAddress(Set<String> address) {
	this.address = address;
}
public Map<Integer, String> getCourse() {
	return course;
}
public void setCourse(Map<Integer, String> course) {
	this.course = course;
}
@Override
public String toString() {
	return "Student [name=" + name + ", phoneNo=" + phoneNo + ", address=" + address + ", course=" + course + "]";
}



}
