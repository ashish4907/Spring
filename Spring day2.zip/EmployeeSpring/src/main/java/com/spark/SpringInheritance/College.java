package com.spark.SpringInheritance;

public class College extends Student {

	private String collegeName;

	public String getCollegeName() {
		return collegeName;
	}

	public void setCollegeName(String collegeName) {
		this.collegeName = collegeName;
	}

	@Override
	public String toString() {
		return super.getStudentId()+" "+super.getStudentName()+" "+super.getStudentGender()+" "+getCollegeName();
	}

	public void sleep() {
		System.out.println("Not sleeping in college");
	}

}
