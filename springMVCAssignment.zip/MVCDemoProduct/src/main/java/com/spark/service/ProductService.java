package com.spark.service;

public interface ProductService {
public void insert(String pname,int pprice);
//public boolean insert(String pname,int pprice);

boolean update(int id, String ppname,int pprice);
}
