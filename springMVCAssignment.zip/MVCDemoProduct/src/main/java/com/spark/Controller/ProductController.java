package com.spark.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.spark.implementation.AddServiceImpl;

@Controller
public class ProductController {

	@RequestMapping("/product")
	public ModelAndView add(HttpServletRequest request, HttpServletResponse response) {
		
//		public ModelAndView add(@RequestParam("pname")String name),  @RequestParam("pprice")int price) {
		
		
		
		String pname = request.getParameter("pname");
		int pprice = Integer.parseInt(request.getParameter("pprice"));

		AddServiceImpl asi = new AddServiceImpl();

		try {
			if (pname == "") {
				asi.insert(pname, pprice);

			} else {

				System.out.println("Data Already exists");
			}
		} catch (Exception e) {
			e.getStackTrace();
		}
//		asi.insert(pname, pprice);

		String outputProduct = "Data added" + " " + "Product Name " + pname + " " + "Price" + pprice;
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("display.jsp");
		modelAndView.addObject("outputProduct", outputProduct);

		return modelAndView;

	}

}
