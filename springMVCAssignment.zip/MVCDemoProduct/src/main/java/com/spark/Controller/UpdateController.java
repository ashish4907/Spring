package com.spark.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.spark.implementation.AddServiceImpl;

@Controller
public class UpdateController {
	@RequestMapping("/productupdate")
	public ModelAndView add(HttpServletRequest request, HttpServletResponse response) {
		int id = Integer.parseInt(request.getParameter("pid"));
		String pupdate = request.getParameter("pnameupdate");
		int pprice = Integer.parseInt(request.getParameter("ppriceupdate"));

		AddServiceImpl asi = new AddServiceImpl();
		boolean updated = asi.update(id, pupdate, pprice);

		String outputProduct = null;
		if (updated) {
			outputProduct = "Data updated" + " " + "Product Name " + pupdate + " " + "id" + id + "price" + pprice;
		} else {
			outputProduct = "Id Not Found";
		}

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("display.jsp");
		modelAndView.addObject("outputProduct", outputProduct);

		return modelAndView;
	}

	
}
