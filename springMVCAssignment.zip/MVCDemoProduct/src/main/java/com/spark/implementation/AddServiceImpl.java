package com.spark.implementation;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.NativeQuery;
import org.hibernate.query.Query;

import com.spark.service.ProductService;

public class AddServiceImpl implements ProductService {

	public Session hibernateConfig() {
		Configuration config = new Configuration().configure().addAnnotatedClass(Product.class);
		SessionFactory sf = config.buildSessionFactory();
		Session session = sf.openSession();
		return session;
	}

	@Override
	public void insert(String pname, int pprice) {
		Product p = new Product();
		p.setPname(pname);
		p.setPprice(pprice);

		Session hibernateConfig = hibernateConfig();

		Session session = (Session) hibernateConfig.save(p);
		Transaction t = session.beginTransaction();
		t.commit();

	}

	@Override
	public boolean update(int id, String ppname, int pprice) {

		Session hibernateConfig = hibernateConfig();

		Product product = hibernateConfig.get(Product.class, id);
		if (product != null) {

			product.setPname(ppname);
			product.setPprice(pprice);

			Session session = (Session) hibernateConfig().save(product);
			Transaction t = session.beginTransaction();
			t.commit();

			return true;

		} else {
			System.out.println("NOT FOUND");
			return false;
		}

	}

}
