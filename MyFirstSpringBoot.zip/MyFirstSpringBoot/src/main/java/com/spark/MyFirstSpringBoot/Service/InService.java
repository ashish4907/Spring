package com.spark.MyFirstSpringBoot.Service;

public interface InService {
    public void insertData(String name, int price);



}
