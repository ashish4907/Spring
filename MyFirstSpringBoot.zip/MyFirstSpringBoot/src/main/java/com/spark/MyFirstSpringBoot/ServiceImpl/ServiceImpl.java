package com.spark.MyFirstSpringBoot.ServiceImpl;

import com.spark.MyFirstSpringBoot.Service.InService;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.spi.Configurable;
import org.hibernate.service.spi.ServiceRegistryImplementor;

public class ServiceImpl implements InService {

    @Override
    public void insertData(String name, int price) {
        Product p = new Product();
        p.setpName(name);
        p.setpPrice(price);
        Configuration  cfg = new Configuration().configure().addAnnotatedClass(Product.class);
        SessionFactory sf = cfg.buildSessionFactory();
        Session session= sf.openSession();
        Transaction trans = session.beginTransaction();
        session.save(p);
        session.close();

    }
}
