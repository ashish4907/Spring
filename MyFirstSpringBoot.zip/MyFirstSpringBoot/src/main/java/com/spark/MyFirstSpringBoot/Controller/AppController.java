package com.spark.MyFirstSpringBoot.Controller;

import com.spark.MyFirstSpringBoot.Service.InService;
import com.spark.MyFirstSpringBoot.ServiceImpl.ServiceImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;
import java.util.List;

@RestController
public class AppController {
    @GetMapping("/demo")
    public List<String> staterApp(){
        List<String> list= Arrays.asList("Welcome", "sparkian","Bengluru ", "Karnataka");
        return list;
    }
@GetMapping("/prod")
    public void getController(HttpServletRequest request , HttpServletResponse response){
      String name = request.getParameter("pName");
      int price = Integer.parseInt(request.getParameter("pPrice"));
        InService serv = new ServiceImpl();
        serv.insertData(name, price);
    }




}
