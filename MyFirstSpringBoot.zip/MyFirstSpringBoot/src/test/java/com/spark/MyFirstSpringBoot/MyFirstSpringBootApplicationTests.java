package com.spark.MyFirstSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyFirstSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
