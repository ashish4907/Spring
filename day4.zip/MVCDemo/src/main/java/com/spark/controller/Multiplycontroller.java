package com.spark.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class Multiplycontroller {
	@RequestMapping("/multiply")

	public ModelAndView multiply(HttpServletRequest request, HttpServletResponse response) {

		int number1 = Integer.parseInt(request.getParameter("number1"));
		int number2 = Integer.parseInt(request.getParameter("number2"));

		MultiplicationServiceImp msi = new MultiplicationServiceImp();
		long calculatedValue = msi.getCalculatedValue(number1, number2);

		String outputProduct = "Multiplication of" + " " + number1 + " " + "and " + number2 + " " + " = "
				+ calculatedValue;

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("display.jsp");
		modelAndView.addObject("outputProduct", outputProduct);

		return modelAndView;
	}

}
