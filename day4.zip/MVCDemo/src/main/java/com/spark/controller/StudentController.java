package com.spark.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class StudentController {

	@RequestMapping("/student")
	public ModelAndView studentDetail(HttpServletRequest request, HttpServletResponse response) {

		String name = request.getParameter("name");
		long contact = Long.parseLong(request.getParameter("contact"));
		
		String output = "Welcome to"+" "+name+" "+"contact is"+" "+contact;
		
		
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("display.jsp");
		modelAndView.addObject("output", output);

		return modelAndView;
	}
}
