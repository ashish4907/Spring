package com.spark.controller;

public interface CalculatorService {
	
	public long getCalculatedValue(int number1,int number2);

}
