package com.spark.controller;

import org.springframework.stereotype.Component;

//@Component
public class MultiplicationServiceImp implements CalculatorService{

	@Override
	public long getCalculatedValue(int number1, int number2) {
		long product = number1 * number2;
		return product;
	}

}
