package com.spark.AdviceSpring;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Component
@Aspect
@EnableAspectJAutoProxy
public class Server {
	@Before("execution(public void invokeServer())")
	
	public void serve() {
		System.out.println("At your Service");
	}

}
