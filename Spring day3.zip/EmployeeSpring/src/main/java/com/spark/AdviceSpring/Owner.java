package com.spark.AdviceSpring;

import org.springframework.stereotype.Component;

@Component
public class Owner {

	public void invokeServer() {
		System.out.println("Server is invoked");
	}

}
