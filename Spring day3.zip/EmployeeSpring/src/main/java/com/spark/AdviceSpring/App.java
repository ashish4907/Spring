package com.spark.AdviceSpring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

import com.spark.manualbean.AppConfig;


public class App {
	public static void main(String[] args) {
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		 Owner bean = context.getBean(Owner.class);
		 bean.invokeServer();
		 context.close();
		
	}

}
