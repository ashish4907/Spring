package com.spark.SpringInheritance;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("studentinhertiancespring.xml");
		College bean = (College) context.getBean("collegeBean", College.class);
		System.out.println(bean);
		
		bean.sleep();
		

	}

}
