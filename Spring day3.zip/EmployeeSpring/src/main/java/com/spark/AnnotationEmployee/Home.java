package com.spark.AnnotationEmployee;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName = "prototype")
public class Home {
	public void comeHome() {
		System.out.println("After interview I will come");
	}

}
