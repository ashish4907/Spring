package com.spark.AnnotationEmployee;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) {
		AbstractApplicationContext context = new ClassPathXmlApplicationContext("annotationemployeespring.xml");
		System.out.println("----------First Bean--------------");
		Employee bean1 = context.getBean(Employee.class);
		System.out.println(bean1.hashCode());
		bean1.call();

		System.out.println("----------Second Bean--------------");
		Employee bean2 = context.getBean(Employee.class);
		System.out.println(bean2.hashCode());
		bean2.call();
		context.close();
		System.out.println(bean1);
		System.out.println(bean2);
	}

}
