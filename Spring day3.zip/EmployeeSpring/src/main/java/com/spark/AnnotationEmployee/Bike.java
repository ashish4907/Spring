package com.spark.AnnotationEmployee;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName = "prototype")
public class Bike {
	public void startBike() {
		System.out.println("Starting the Bike");
	}
	public void stopBike() {
		System.out.println("Stop the Bike");
	}

}
