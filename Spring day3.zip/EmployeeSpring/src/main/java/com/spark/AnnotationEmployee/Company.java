package com.spark.AnnotationEmployee;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName = "prototype")
public class Company {
	public  void recuritDrive() {
		System.out.println("Recuriting the Employee");
	}
}
