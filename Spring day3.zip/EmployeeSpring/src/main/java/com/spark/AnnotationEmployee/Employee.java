package com.spark.AnnotationEmployee;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope(scopeName = "prototype")
public class Employee {
	@Autowired
	private Company company;

	@Autowired
	private Home home;
	@Autowired
	private Bike bike;

	public void call() {
		company.recuritDrive();
		System.out.println("Recurited Done");
		bike.startBike();
		home.comeHome();
		bike.stopBike();
		

	}

	@Override
	public String toString() {
		return "Employee [company=" + company + ", home=" + home + ", bike=" + bike + "]";
	}
	
	
}
