package com.spark.SpringLifeCycleDB;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentDAO {

	private String driver;
	private String url;
	private String username;
	private String password;

	Connection conn;

	public String getDriver() {
		return driver;
	}

	public void setDriver(String driver) {
		System.out.println("Setting Driver");
		this.driver = driver;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		System.out.println("Setting Url");
		this.url = url;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		System.out.println("Setting UserName");
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		System.out.println("Setting Password");
		this.password = password;
	}

	public void init() throws ClassNotFoundException, SQLException {
		System.out.println("inside the custom init method");
		createConnection();
	}

	public void createConnection() throws ClassNotFoundException, SQLException {
		System.out.println("Create Connection");
		Class.forName(driver);
		conn = DriverManager.getConnection(url, username, password);

	}

	public void fetchData() throws ClassNotFoundException, SQLException {
		System.out.println("Fetching all the Data");
		Statement stm = conn.createStatement();

		ResultSet rs = stm.executeQuery("Select * from student");
		while (rs.next()) {
			Integer id = rs.getInt("id");
			String name = rs.getString("name");
			String dept = rs.getString("dept");
			Date date = rs.getDate("DOJ");

			System.out.println(id + " " + name + " " + dept + " " + date);
		}

		System.out.println("destroying the method");
	}

	public void deleteData(int id) throws ClassNotFoundException, SQLException {

		Statement stm = conn.createStatement();

		stm.executeUpdate("delete from student where id=" + id);
		System.out.println("Record deleted with id" + id);

	}

	public void closeConnection() throws SQLException {
		conn.close();

	}

	public void destroy() throws SQLException {
		System.out.println("inside the destroy custom method");
		closeConnection();
	}
}
