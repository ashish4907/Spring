package com.spark.SpringLifeCycleDB;

import java.sql.SQLException;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {

		AbstractApplicationContext context = new ClassPathXmlApplicationContext("StudentDAOSpring.xml");
		StudentDAO bean = (StudentDAO) context.getBean("studentDAO");
		System.out.println(bean);
		bean.fetchData();
		context.close();
	}

}
