package com.spark.LifeCycle;

public class LifeCycleBean {
	public void init() {
		System.out.println("Initialization begins...");
		System.out.println(12/6);
	}
	public void display() {
		System.out.println("I am in LifeCycleTest Object");
	}


	public void destroy() {
		System.out.println("All beans are destroyed...");
	}

}
