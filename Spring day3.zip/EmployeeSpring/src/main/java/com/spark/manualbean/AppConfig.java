package com.spark.manualbean;


import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = "com.spark.manualbean")
public class AppConfig {

	/*
	 * @Bean public HP get() { return new HP(); }
	 * 
	 * @Bean public GPUProcessor getGPU() { return new GPUProcessor(); }
	 */
}
