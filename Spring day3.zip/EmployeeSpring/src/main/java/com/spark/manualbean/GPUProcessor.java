package com.spark.manualbean;

import org.springframework.stereotype.Component;

@Component
public class GPUProcessor {

	public void getGPU() {
		System.out.println("NVIDIA");
	}
}
