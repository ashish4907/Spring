package com.spark.manualbean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class HP {
	@Autowired
	private GPUProcessor GPU;

	public void getConf() {
		System.out.println("I7 11st gen octacore");
		GPU.getGPU();
	}
}
