package com.spark.manualbean;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.After;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.stereotype.Component;

@Component
@Aspect
@EnableAspectJAutoProxy
public class Server {
//	@Before("execution(public void invokeServer())")  //before the method execution
//	@After("execution(public void invokeServer())")   // after the method execution
//	@AfterThrowing("execution(public void invokeServer())") 
//	@AfterReturning("execution(public void invokeServer())")
	@Around("execution(public void invokeServer())")

	
//	  public void serve() { System.out.println("At your Service");
//	  
//	  
//	  }
	 

	public void serve(ProceedingJoinPoint pjp) throws Throwable {
		System.out.println("Start");
		pjp.proceed();
		System.out.println("end");
	}

}
