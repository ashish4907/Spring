package com.spark.manualbean;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;

public class App {
	public static void main(String[] args) {
		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
//		HP bean = context.getBean(HP.class);
		Owner bean2 = context.getBean(Owner.class);

		try {
			bean2.invokeServer();

		} catch (Exception e) {
			System.out.println(e);
		}
//		bean2.printThrowException();
		context.close();
	}
}
