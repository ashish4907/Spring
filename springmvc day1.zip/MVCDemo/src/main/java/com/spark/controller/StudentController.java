package com.spark.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class StudentController {
	
	@RequestMapping("/student")
	public String studentDetail() {
//		System.out.println("Got the Student Detail");
		return "display.jsp";
	}
}
