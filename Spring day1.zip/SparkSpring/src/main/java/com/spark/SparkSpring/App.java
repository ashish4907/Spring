package com.spark.SparkSpring;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.FileSystemResource;

public class App {

	public static void main(String[] args) {
		/*
		 * spring.xml file should be in SparkSpring BeanFactory factory = new
		 * XmlBeanFactory(new FileSystemResource("spring.xml")); Cat bean = (Cat)
		 * factory.getBean("catBean"); bean.eat();
		 * 
		 * Dog bean2 = (Dog) factory.getBean("dogBean"); bean2.eat();
		 */

		// spring.xml should be in src/main/java
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Cat bean = (Cat) context.getBean("catBean");
		bean.eat();

		Dog bean2 = (Dog) context.getBean("dogBean");
		bean2.eat();
	}
}
