package com.spark.SparkSpring;

public interface Animal {
	void eat();
}
