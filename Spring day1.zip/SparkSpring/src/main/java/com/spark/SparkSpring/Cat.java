package com.spark.SparkSpring;

public class Cat implements Animal {
	public void eat() {
		System.out.println("Cat is Eating");
	}
}
