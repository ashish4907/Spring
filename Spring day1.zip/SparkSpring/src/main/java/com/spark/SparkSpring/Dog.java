package com.spark.SparkSpring;

public class Dog implements Animal {
	public void eat() {
		System.out.println("Dog is Eating");
	}
}
