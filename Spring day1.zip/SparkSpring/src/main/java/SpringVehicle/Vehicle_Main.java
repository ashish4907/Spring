package SpringVehicle;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Vehicle_Main {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("spring.xml");
		Car carBean = (Car) context.getBean("carBean");
		Bus busBean = (Bus) context.getBean("busBean");

		carBean.drive();
		busBean.drive();

		System.out.println(carBean.getColor());
		
	

	}

}
