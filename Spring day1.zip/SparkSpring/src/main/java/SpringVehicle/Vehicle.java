package SpringVehicle;

public interface Vehicle {
void drive();
}
