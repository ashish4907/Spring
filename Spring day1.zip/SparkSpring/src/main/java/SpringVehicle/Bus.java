package SpringVehicle;

public class Bus implements Vehicle{
public void drive() {
	System.out.println("Bus is driving");
}
}
