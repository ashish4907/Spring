package SpringVehicle;

public class Car implements Vehicle {
	private String color;

	@Override
	public String toString() {
		return "Car [color=" + color + "]";
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void drive() {
		System.out.println("Car is driving");
	}
}
