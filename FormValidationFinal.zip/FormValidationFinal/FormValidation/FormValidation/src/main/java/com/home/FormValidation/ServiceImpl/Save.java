package com.home.FormValidation.ServiceImpl;

import com.home.FormValidation.DTO.LoginForm;
import com.home.FormValidation.DTO.Response;
import com.home.FormValidation.Repo.LoginRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestBody;

@Component
@Async
public class Save {
    @Autowired
    private LoginForm loginForm;
    @Autowired
    private Response response;
    @Autowired
    private LoginRepo loginRepo;
    @Autowired
    private ValidationServiceImpl validationService;
    public void saving(@RequestBody LoginForm loginForm){

        String password = loginForm.getPassword();
        String userName = loginForm.getUserName();

        loginForm.setUserName(userName);
        loginForm.setPassword(password);
        loginRepo.save(loginForm);
    }

}
