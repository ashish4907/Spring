package com.home.FormValidation.Service;

import com.home.FormValidation.DTO.LoginForm;
import com.home.FormValidation.DTO.Response;

public interface FormValidation {
/*public String login(String userName, String password);*/

    String login(LoginForm loginForm);
}
