package com.home.FormValidation.ServiceImpl;

import com.home.FormValidation.DTO.LoginForm;
import com.home.FormValidation.DTO.Response;
import com.home.FormValidation.Repo.LoginRepo;
import com.home.FormValidation.Service.FormValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class FormValidationImpl implements FormValidation {
    String message = "Check and Validate Your Password";
    @Autowired
    private LoginForm loginForm;
    @Autowired
    private Response response;
    @Autowired
    private LoginRepo loginRepo;
    @Autowired
    private ValidationServiceImpl validationService;

@Autowired
private Save save;

    @Override
   /* @Async*/
    public String login(LoginForm loginForm) {
        String password = loginForm.getPassword();
        String userName = loginForm.getUserName();

    /*    boolean digits = validationService.digits(password);
        boolean lcase = validationService.lowerCase(password);
        boolean ucase = validationService.upperCase(password);
        boolean special = validationService.specialCharacter(password);*/


        List<LoginForm> all = loginRepo.findAll();
        List<String> name = all.stream().map(e -> e.getUserName()).collect(Collectors.toList());
        System.out.println(name);

        boolean hasLower = false, hasUpper = false, hasDigit = false, specialChar = false;
        Set<Character> set = new HashSet<Character>(Arrays.asList('!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-', '+', '/', ':', '.', ',', '<', '>', '?', '|'));
        for (char i : password.toCharArray()) {
            if (Character.isLowerCase(i)) hasLower = true;
            if (Character.isUpperCase(i)) hasUpper = true;
            if (Character.isDigit(i)) hasDigit = true;
            if (set.contains(i)) specialChar = true;
        }
        if (hasDigit && hasLower && hasUpper && specialChar && (password.length() > 16 && !password.contains(" "))) {

            save.saving(loginForm);
/*
            loginForm.setUserName(userName);
            loginForm.setPassword(password);
            loginRepo.save(loginForm);*/

           return "Saved And Very Strong Password";


        } else if ((hasDigit && hasLower && hasUpper && specialChar) && (password.length() > 10 && password.length() <= 16 && !password.contains(" "))) {
            save.saving(loginForm);

            /*loginForm.setUserName(userName);
            loginForm.setPassword(password);
            loginRepo.save(loginForm);*/
           /* response.setStatusCode(HttpStatus.OK.value() + "");
            response.setStatusMessage("Saved And Strong Password");
            return response;*/
            return "Saved And Strong Password";


        } else if ((hasDigit && hasLower && hasUpper && specialChar) && (password.length() > 8 && password.length() <= 10 && !password.contains(" "))) {

            save.saving(loginForm);
           /* loginForm.setUserName(userName);
            loginForm.setPassword(password);
            loginRepo.save(loginForm);*/

            return "Saved And Medium Strong Password";


        } else if ((hasDigit && hasLower || hasUpper || specialChar) && (password.length() >= 4 && password.length() <= 8 && !password.contains(" "))) {

            return "Weak Password - Check Your Password";
        }


        return "Very Weak Password - Check Your Password";

    }


}









      /*  if (password != null && !password.isEmpty() && userName != null && !userName.isEmpty()) {

            if (password.length() > 16 && !password.contains(" ")) {
                if (validationService.digits(password)) {

                    if (validationService.upperCase(password)) {
                        if (validationService.lowerCase(password)) {
                            if (validationService.specialCharacter(password)) {
                                loginForm.setUserName(userName);
                                loginForm.setPassword(password);
                                loginRepo.save(loginForm);
                                return "Strong Password" + " " + userName;
                            *//*response.setStatusCode(HttpStatus.OK.value() + "");
                                response.setStatusMessage("Success");
                                return response;*//*
                            }
                        }
                    }
                }
            }

        } else if (password.length() >= 6 && password.length() <= 16 && !password.contains(" ")) {
            if (validationService.digits(password)) {

                if (validationService.upperCase(password)) {
                    if (validationService.lowerCase(password)) {
                        if (validationService.specialCharacter(password)) {
                            loginForm.setUserName(userName);
                            loginForm.setPassword(password);
                            loginRepo.save(loginForm);
                            return "Medium Password" + " " + userName;
                            *//*response.setStatusCode(HttpStatus.OK.value() + "");
                                response.setStatusMessage("Success");
                                return response;*//*
                        }
                    }
                }
            }
        }
        return "Weak Password";
    }*/



       /* response.setStatusCode(HttpStatus.BAD_GATEWAY.value()+"");
            response.setStatusMessage("Check Your Password");
            return response;*/


/*if (password.length() >= 8 && !password.contains(" ")) {
        if (validationService.digits(password)) {

                if (validationService.upperCase(password)) {
                    if (validationService.lowerCase(password)) {
                if (validationService.specialCharacter(password)) {
                    loginForm.setUserName(userName);
                    loginForm.setPassword(password);
                    loginRepo.save(loginForm);
                    return "Hello World" + " " + userName;
                            *//*response.setStatusCode(HttpStatus.OK.value() + "");
                                response.setStatusMessage("Success");
                                return response;*//*
                }
            }
        }
    }
        }

    }*/



