package com.home.FormValidation.Controller;


import com.home.FormValidation.DTO.LoginForm;
import com.home.FormValidation.DTO.Response;
import com.home.FormValidation.Service.FormValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController


public class FormController {

    @Autowired
    private FormValidation validationService;

    @Autowired
    Response response;

    @PostMapping("/form")
    public String login(@RequestBody LoginForm loginForm) {
        return  validationService.login(loginForm);

    }

}
