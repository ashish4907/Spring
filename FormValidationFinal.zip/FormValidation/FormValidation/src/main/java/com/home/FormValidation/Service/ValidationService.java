package com.home.FormValidation.Service;

public interface ValidationService {


    boolean specialCharacter(String password);

    boolean digits(String password);

    boolean lowerCase(String password);

    boolean upperCase(String password);
}
