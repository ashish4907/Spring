package com.home.FormValidation.ServiceImpl;

import com.home.FormValidation.DTO.LoginForm;
import com.home.FormValidation.DTO.Response;
import com.home.FormValidation.Repo.LoginRepo;
import com.home.FormValidation.Service.FormValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

@Service
public class FormValidationImpl implements FormValidation {
    @Autowired
    private LoginForm loginForm;

    @Autowired
    private Response response;

    @Autowired
    private LoginRepo loginRepo;

    @Autowired
    private ValidationServiceImpl validationService;

    @Override

    public String login(String userName, String password) {
if( password!=null && !password.isEmpty() &&userName!=null && !userName.isEmpty() ) {

    if (password.length() >= 8 && !password.contains(" ")) {
        if (validationService.digits(password)) {
                if (validationService.upperCase(password)) {
                    if (validationService.lowerCase(password)) {
                        if (validationService.specialCharacter(password)) {
                            loginForm.setUserName(userName);
                            loginForm.setPassword(password);
                            loginRepo.save(loginForm);
                            return "Hello World" + " " + userName;
                            /*response.setStatusCode(HttpStatus.OK.value() + "");
                                response.setStatusMessage("Success");
                                return response;*/
                        }
                    }
                }
            }
        }

    }

    String message="Check and Validate Your Password";
    return message;
       /* response.setStatusCode(HttpStatus.BAD_GATEWAY.value()+"");
            response.setStatusMessage("Check Your Password");
            return response;*/
    }
}
