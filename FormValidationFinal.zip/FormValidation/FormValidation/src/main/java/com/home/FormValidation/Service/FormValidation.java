package com.home.FormValidation.Service;

public interface FormValidation {
public String login(String userName,String password);


}
