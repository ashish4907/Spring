package com.home.FormValidation.ServiceImpl;

import com.home.FormValidation.Service.ValidationService;
import org.springframework.stereotype.Service;

@Service
public class ValidationServiceImpl implements ValidationService {


    @Override

    public boolean specialCharacter(String password) {
        if ((password.contains("@") || password.contains("#")
                || password.contains("!") || password.contains("~")
                || password.contains("$") || password.contains("%")
                || password.contains("^") || password.contains("&")
                || password.contains("*") || password.contains("(")
                || password.contains(")") || password.contains("-")
                || password.contains("+") || password.contains("/")
                || password.contains(":") || password.contains(".")
                || password.contains(", ") || password.contains("<")
                || password.contains(">") || password.contains("?")
                || password.contains("|"))) {
            return true;
        }
        return false;
    }

  /*  public boolean specialCharacter(String password) {
        char[] ch = password.toCharArray();
        for(int i= 0;i<password.length();i++)
        {
            if ((ch[i]>= (char) (32) && ch[i]<= (char) (47)) || (ch[i]>= (char) (58) && ch[i]<= (char) (64)) || (ch[i] >= (char) (91) && ch[i] <= (char) (96)) || (ch[i] >= (char) (123) && ch[i] <= (char) (126)))
            {
                return true;
            }
        }
        return false;
    }*/

    @Override
    public boolean digits(String password) {
        char[] ch = password.toCharArray();
        for (int i = 0; i < password.length(); i++) {
            if (ch[i] >= '0' && ch[i] <= '9') {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean lowerCase(String password) {
        char[] ch = password.toCharArray();
        for (int i = 0; i < password.length(); i++) {
            if (ch[i] >= 'a' && ch[i] <= 'z') {
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean upperCase(String password) {
        char[] ch = password.toCharArray();
        for (int i = 0; i < password.length(); i++) {
            if (ch[i] >= 'A' && ch[i] <= 'Z') {
                return true;
            }
        }
        return false;
    }

}



