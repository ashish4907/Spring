package com.home.FormValidation.Controller;


import com.home.FormValidation.Service.FormValidation;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController


public class FormController {

    @Autowired
    private FormValidation validationService;

    @PostMapping("/form")
    public String login(@RequestParam String userName, @RequestParam String password) {
        return validationService.login(userName, password);
    }

}
